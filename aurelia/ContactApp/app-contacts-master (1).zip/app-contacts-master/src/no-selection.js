export class NoSelection{
  constructor(){
    this.message = "Please Select a Contact.";
  }
}
